#!/bin/bash
count=1

employees=(
    ["John"]=45
    ["Mary"]=42
    ["Peter"]=50
    ["Alice"]=38
    ["Bob"]=48
    ["Diana"]=40
    ["Chris"]=43
    ["Emma"]=35
    ["David"]=52
    ["Sarah"]=47
)
while [ $count -le 10 ]
do
    echo "Enter no of hours employee $count has worked"
    read hours
    if [ $hours -gt 40 ]
    then
        ot=$((hours - 40))
        otpay=$((ot * 12))
        echo "Employee $count has worked $hours hours. Overtime pay is Rs $otpay"
    else
        echo "Employee $count has not worked overtime, so no overtime pay"
    fi
    count=$((count + 1))
done

